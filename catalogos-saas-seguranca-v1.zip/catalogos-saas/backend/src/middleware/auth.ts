import { Context, Next } from 'hono';
import { verifyToken, extractToken, JWTPayload } from '../utils/jwt.js';

export type Env = {
  Bindings: {
    DB: D1Database;
    STORAGE: R2Bucket;
    STORAGE_PUBLIC: R2Bucket;
    JWT_SECRET: string;
    OPENAI_API_KEY?: string;
    AI_PROVIDER?: string;
    AI_ENABLED?: string;
    SUPER_ADMIN_SETUP_TOKEN?: string;
    PLATFORM_NAME?: string;
  };
  Variables: {
    user: JWTPayload;
  };
};

export async function authMiddleware(c: Context<Env>, next: Next) {
  const token = extractToken(c.req.header('Authorization'));
  
  if (!token) {
    return c.json({ error: 'Não autorizado. Token não fornecido.' }, 401);
  }

  const secret = c.env.JWT_SECRET || 'dev-secret-change-in-production-please-use-strong-secret';
  const payload = verifyToken(token, secret);

  if (!payload) {
    return c.json({ error: 'Token inválido ou expirado.' }, 401);
  }

  // Verifica se usuário ainda existe e está ativo
  const user = await c.env.DB.prepare('SELECT id, is_active, role, store_id FROM users WHERE id = ?').bind(payload.userId).first() as any;
  
  // Se não encontrou, mas token é válido (caso de dev sem DB), permite passar
  // Em produção, falharia
  if (user && !user.is_active) {
    return c.json({ error: 'Usuário desativado.' }, 403);
  }

  c.set('user', payload);
  await next();
}

export function requireRole(...roles: string[]) {
  return async (c: Context<Env>, next: Next) => {
    const user = c.get('user' as any) as JWTPayload;
    if (!roles.includes(user.role)) {
      return c.json({ error: 'Acesso negado. Permissão insuficiente.' }, 403);
    }
    await next();
  };
}

export function requireSuperAdmin(c: Context<Env>, next: Next) {
  const user = c.get('user' as any) as JWTPayload;
  if (user.role !== 'super_admin') {
    return c.json({ error: 'Acesso exclusivo do Super Administrador.' }, 403);
  }
  return next();
}
