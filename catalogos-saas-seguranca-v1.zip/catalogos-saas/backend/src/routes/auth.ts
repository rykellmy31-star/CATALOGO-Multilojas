import { Hono } from 'hono';
import { zValidator } from '../middleware/validation.js';
import { loginSchema, setupSuperAdminSchema } from '../utils/validation.js';
import { hashPassword, verifyPassword } from '../utils/hash.js';
import { signToken } from '../utils/jwt.js';
import { authMiddleware } from '../middleware/auth.js';

type Env = {
  Bindings: {
    DB: D1Database;
    JWT_SECRET: string;
    SUPER_ADMIN_SETUP_TOKEN: string;
  };
};

const auth = new Hono<Env>();

// POST /api/auth/login
auth.post('/login', zValidator('json', loginSchema), async (c) => {
  const { email, password } = c.req.valid('json' as any) as any;

  const user = await c.env.DB.prepare(
    'SELECT id, name, email, password_hash, role, store_id, is_active FROM users WHERE email = ?'
  ).bind(email).first() as any;

  if (!user) {
    return c.json({ error: 'Email ou senha inválidos.' }, 401);
  }

  if (!user.is_active) {
    return c.json({ error: 'Usuário desativado. Contate o administrador.' }, 403);
  }

  const valid = await verifyPassword(password, user.password_hash);
  
  if (!valid) {
    return c.json({ error: 'Email ou senha inválidos.' }, 401);
  }

  // Verifica se loja está ativa (para store_admin)
  if (user.role === 'store_admin' && user.store_id) {
    const store = await c.env.DB.prepare('SELECT status FROM stores WHERE id = ?').bind(user.store_id).first() as any;
    if (store && store.status === 'suspended') {
      return c.json({ error: 'Loja suspensa. Contate o Super Administrador.' }, 403);
    }
    if (store && store.status === 'deleted') {
      return c.json({ error: 'Loja não encontrada.' }, 404);
    }
  }

  const secret = c.env.JWT_SECRET;
  if (!secret || secret.length < 32) {
    console.error('JWT_SECRET ausente ou insuficiente');
    return c.json({ error: 'Configuração de autenticação indisponível.' }, 503);
  }
  const token = signToken({
    userId: user.id,
    email: user.email,
    role: user.role,
    storeId: user.store_id
  }, secret, '7d');

  // Atualiza last_login
  await c.env.DB.prepare('UPDATE users SET last_login_at = datetime("now") WHERE id = ?').bind(user.id).run();

  // Audit log
  await c.env.DB.prepare(
    'INSERT INTO audit_logs (user_id, store_id, action, entity_type, details) VALUES (?, ?, ?, ?, ?)'
  ).bind(user.id, user.store_id || null, 'login', 'user', JSON.stringify({ email })).run().catch(()=>{});

  return c.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      storeId: user.store_id
    }
  });
});

// POST /api/auth/setup-super-admin - Criar primeiro super admin (sem auth, com token)
auth.post('/setup-super-admin', zValidator('json', setupSuperAdminSchema), async (c) => {
  const { setupToken, name, email, password } = c.req.valid('json' as any) as any;

  // Verifica se já existe super admin
  const existing = await c.env.DB.prepare("SELECT id FROM users WHERE role = 'super_admin' LIMIT 1").first();
  if (existing) {
    return c.json({ error: 'Super Administrador já existe. Faça login normalmente.' }, 409);
  }

  // Valida token de setup
  const expectedToken = c.env.SUPER_ADMIN_SETUP_TOKEN || 'setup-dev-token-change-me';
  if (setupToken !== expectedToken) {
    return c.json({ error: 'Token de configuração inválido.' }, 403);
  }

  // Verifica se email já existe
  const existingEmail = await c.env.DB.prepare('SELECT id FROM users WHERE email = ?').bind(email).first();
  if (existingEmail) {
    return c.json({ error: 'Email já cadastrado.' }, 409);
  }

  const passwordHash = await hashPassword(password);
  const userId = crypto.randomUUID();

  await c.env.DB.prepare(
    'INSERT INTO users (id, name, email, password_hash, role, store_id, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).bind(userId, name, email, passwordHash, 'super_admin', null, 1).run();

  await c.env.DB.prepare(
    'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES (?, ?, ?, ?, ?)'
  ).bind(userId, 'create_super_admin', 'user', userId, JSON.stringify({ email, name })).run().catch(()=>{});

  const secret = c.env.JWT_SECRET;
  if (!secret || secret.length < 32) {
    console.error('JWT_SECRET ausente ou insuficiente');
    return c.json({ error: 'Configuração de autenticação indisponível.' }, 503);
  }
  const token = signToken({
    userId,
    email,
    role: 'super_admin',
    storeId: null
  }, secret);

  return c.json({
    message: 'Super Administrador criado com sucesso!',
    token,
    user: { id: userId, name, email, role: 'super_admin', storeId: null }
  }, 201);
});

// GET /api/auth/check-setup - Verifica se precisa configurar super admin
auth.get('/check-setup', async (c) => {
  const existing = await c.env.DB.prepare("SELECT id FROM users WHERE role = 'super_admin' LIMIT 1").first();
  return c.json({ needsSetup: !existing });
});

// GET /api/auth/me
auth.get('/me', authMiddleware as any, async (c) => {
  const user = (c as any).get('user');
  const dbUser = await c.env.DB.prepare('SELECT id, name, email, role, store_id, avatar_url FROM users WHERE id = ?').bind(user.userId).first() as any;
  
  if (!dbUser) return c.json({ error: 'Usuário não encontrado' }, 404);

  let store = null;
  if (dbUser.store_id) {
    store = await c.env.DB.prepare('SELECT id, name, slug, logo_url, status FROM stores WHERE id = ?').bind(dbUser.store_id).first();
  }

  return c.json({ user: dbUser, store });
});

// POST /api/auth/logout
auth.post('/logout', authMiddleware as any, async (c) => {
  const user = (c as any).get('user');
  await c.env.DB.prepare(
    'INSERT INTO audit_logs (user_id, store_id, action, entity_type, details) VALUES (?, ?, ?, ?, ?)'
  ).bind(user.userId, user.storeId || null, 'logout', 'user', JSON.stringify({})).run().catch(()=>{});
  return c.json({ message: 'Logout realizado com sucesso' });
});

export default auth;

// Simple zValidator helper inline to avoid extra dep issues
// Actually imported from middleware/validation - create that file
