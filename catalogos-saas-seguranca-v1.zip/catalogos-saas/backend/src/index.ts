import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { secureHeaders } from 'hono/secure-headers';

import authRoutes from './routes/auth.js';
import superadminRoutes from './routes/superadmin.js';
import storeRoutes from './routes/store.js';
import publicRoutes from './routes/public.js';
import uploadRoutes from './routes/upload.js';

type Env = {
  Bindings: {
    DB: D1Database;
    STORAGE: R2Bucket;
    STORAGE_PUBLIC: R2Bucket;
    JWT_SECRET: string;
    OPENAI_API_KEY?: string;
    AI_PROVIDER?: string;
    AI_ENABLED?: string;
    SUPER_ADMIN_SETUP_TOKEN?: string;
    R2_PUBLIC_URL?: string;
    PLATFORM_NAME?: string;
    ENVIRONMENT?: string;
  };
};

const app = new Hono<Env>();

// =============================
// Global Middleware
// =============================
app.use('*', logger());
app.use('*', secureHeaders());
app.use('*', cors({
  origin: (origin) => origin || '*',
  allowHeaders: ['Content-Type', 'Authorization', 'X-Session-Id'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  credentials: true
}));

// =============================
// Health & Root
// =============================
app.get('/', (c) => c.json({
  name: 'Catálogos SaaS API',
  version: '1.0.0',
  status: 'online',
  environment: c.env.ENVIRONMENT || 'production',
  endpoints: {
    auth: '/api/auth',
    superadmin: '/api/superadmin',
    store: '/api/store',
    public: '/api/public',
    upload: '/api/upload',
    health: '/api/health'
  }
}));

app.get('/api/health', (c) => c.json({
  status: 'ok',
  timestamp: new Date().toISOString(),
  database: 'connected',
  storage: 'connected'
}));

// =============================
// API Routes
// =============================
app.route('/api/auth', authRoutes);
app.route('/api/superadmin', superadminRoutes);
app.route('/api/store', storeRoutes);
app.route('/api/public', publicRoutes);
app.route('/api/upload', uploadRoutes);
app.route('/api', uploadRoutes); // Also serve /api/storage/:key

// =============================
// 404 & Error Handlers
// =============================
app.notFound((c) => c.json({ error: 'Rota não encontrada', path: c.req.path }, 404));

app.onError((err, c) => {
  console.error('Unhandled error:', err);
  return c.json({
    error: 'Erro interno do servidor',
    message: c.env.ENVIRONMENT === 'development' ? err.message : 'Tente novamente mais tarde'
  }, 500);
});

// =============================
// Scheduled (Cron) - limpeza analytics antigos, etc
// =============================
// Cloudflare Workers Cron: definido em wrangler.toml [triggers]
// Esta função é chamada automaticamente conforme cron configurado
export async function scheduled(event: ScheduledEvent, env: Env['Bindings'], ctx: ExecutionContext) {
  // Exemplo: limpar analytics com mais de 90 dias
  try {
    await env.DB.prepare("DELETE FROM analytics_events WHERE created_at < datetime('now', '-90 days')").run();
    console.log('Cron: analytics antigos limpos');
  } catch (e) {
    console.error('Cron error:', e);
  }
}

export default app;
